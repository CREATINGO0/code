import java.util.*;

public interface Strategy {

	/**
	* sort method interface
	* @param tasklist the tasklist to be sorted
	*/
	public void sort(TaskList tasklist);

}